# Shwe Myeik Gaming Platform - TODO

## Backend Services (Completed)
- [x] Database schema extended with all required tables
- [x] Internal games seeded (Min Tone Min, Mini Slot)
- [x] Shared constants updated with error messages
- [x] tRPC procedures: adminProcedure, agentProcedure, playerProcedure
- [x] Database helpers: getUserById, getAllUsers, getAccountByUserId, getAgentByUserId, getGameById, getAllGames
- [x] LedgerService: double-entry bookkeeping
- [x] AgentService: agent hierarchy management
- [x] GameEngineService: game mechanics for Min Tone Min and Mini Slot
- [x] TransferService: credit transfers between users
- [x] CreditMintService: admin credit minting

## tRPC Procedures (In Progress)
- [ ] Wire all feature routers in server/routers.ts
  - [ ] server/routers/admin.ts: mint, agents, ledger, stats, users, roles
  - [ ] server/routers/agent.ts: balance, downline, transfers, history
  - [ ] server/routers/player.ts: balance, wallet, games, play, history, profile
  - [ ] server/routers/public.ts: getGames

## Frontend Pages (To Do)
- [ ] Admin Dashboard (/admin/*)
  - [ ] /admin/dashboard: overview stats
  - [ ] /admin/mint: credit minting form
  - [ ] /admin/agents: agent management
  - [ ] /admin/ledger: ledger viewer
  - [ ] /admin/stats: platform stats
  - [ ] /admin/users: user management
  - [ ] AdminLayout component with sidebar

- [ ] Agent Dashboard (/agent/*)
  - [ ] /agent/dashboard: balance overview
  - [ ] /agent/downline: downline management
  - [ ] /agent/transfer: credit transfer form
  - [ ] /agent/history: transaction history
  - [ ] AgentLayout component with sidebar

- [ ] Player Dashboard (/player/*)
  - [ ] /player/dashboard: wallet overview
  - [ ] /player/wallet: balance and transactions
  - [ ] /player/games: games listing
  - [ ] /player/history: game history
  - [ ] /player/profile: account info
  - [ ] PlayerLayout component with sidebar

- [ ] Games
  - [ ] /player/games/min-tone-min: Min Tone Min card game (flagship)
  - [ ] /player/games/mini-slot: Mini Slot game

- [ ] Landing Page & Authentication
  - [ ] / (Home): Landing page for unauthenticated users
  - [ ] Role-based routing: redirect based on user role
  - [ ] Sign In button with OAuth

## UI & Styling
- [ ] Update client/src/index.css with color palette (gold, maroon, navy)
- [ ] Add Poppins font to client/index.html
- [ ] Create reusable layout components
- [ ] Implement loading skeletons and empty states
- [ ] Responsive design for mobile and desktop

## Deployment & Testing
- [ ] Resolve all TypeScript errors
- [ ] Run pnpm check to verify no errors
- [ ] Test all tRPC procedures
- [ ] Deploy using webdev tools
- [ ] Verify deployed URL is accessible
