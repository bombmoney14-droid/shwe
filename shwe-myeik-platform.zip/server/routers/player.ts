import { playerProcedure, router } from '../_core/trpc';
import { z } from 'zod';
import Decimal from 'decimal.js';
import { GameEngineService } from '../services/gameEngineService';
import { TransferService } from '../services/transferService';
import { getDb } from '../db';
import { accounts, internalGames } from '../../drizzle/schema';
import { eq } from 'drizzle-orm';

export const playerRouter = router({
  /**
   * Get player's current balance.
   */
  getBalance: playerProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const account = await db.select().from(accounts).where(eq(accounts.userId, ctx.user.id)).limit(1);

    return {
      balance: account[0]?.balance || '0',
    };
  }),

  /**
   * Get wallet info (balance + recent transactions).
   */
  getWallet: playerProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const account = await db.select().from(accounts).where(eq(accounts.userId, ctx.user.id)).limit(1);
    const transactions = await TransferService.getTransferHistory(ctx.user.id, 10);

    return {
      balance: account[0]?.balance || '0',
      recentTransactions: transactions,
    };
  }),

  /**
   * Get available games.
   */
  getGames: playerProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    return await db.select().from(internalGames).where(eq(internalGames.isActive, 1));
  }),

  /**
   * Play Min Tone Min game.
   */
  playMinToneMin: playerProcedure
    .input(
      z.object({
        betAmount: z.number().positive(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      // Get game ID for Min Tone Min
      const db = await getDb();
      if (!db) throw new Error('Database not available');

      const game = await db
        .select()
        .from(internalGames)
        .where(eq(internalGames.code, 'MIN_TONE_MIN'))
        .limit(1);

      if (game.length === 0) throw new Error('Game not found');

      return await GameEngineService.playMinToneMin(ctx.user.id, game[0].id, new Decimal(input.betAmount));
    }),

  /**
   * Play Mini Slot game.
   */
  playMiniSlot: playerProcedure
    .input(
      z.object({
        betAmount: z.number().positive(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      // Get game ID for Mini Slot
      const db = await getDb();
      if (!db) throw new Error('Database not available');

      const game = await db
        .select()
        .from(internalGames)
        .where(eq(internalGames.code, 'MINI_SLOT'))
        .limit(1);

      if (game.length === 0) throw new Error('Game not found');

      return await GameEngineService.playMiniSlot(ctx.user.id, game[0].id, new Decimal(input.betAmount));
    }),

  /**
   * Get game history.
   */
  getGameHistory: playerProcedure
    .input(
      z.object({
        limit: z.number().default(50),
        offset: z.number().default(0),
      })
    )
    .query(async ({ input, ctx }) => {
      return await GameEngineService.getGameHistory(ctx.user.id, input.limit, input.offset);
    }),

  /**
   * Get player profile.
   */
  getProfile: playerProcedure.query(async ({ ctx }) => {
    return {
      id: ctx.user.id,
      name: ctx.user.name,
      email: ctx.user.email,
      role: ctx.user.role,
      createdAt: ctx.user.createdAt,
      lastSignedIn: ctx.user.lastSignedIn,
    };
  }),
});
