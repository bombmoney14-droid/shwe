import { publicProcedure, router } from '../_core/trpc';
import { getDb } from '../db';
import { internalGames } from '../../drizzle/schema';
import { eq } from 'drizzle-orm';

export const publicRouter = router({
  /**
   * Get all active games (for public homepage).
   */
  getGames: publicProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    return await db.select().from(internalGames).where(eq(internalGames.isActive, 1));
  }),
});
