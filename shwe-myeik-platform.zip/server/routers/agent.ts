import { agentProcedure, router } from '../_core/trpc';
import { z } from 'zod';
import Decimal from 'decimal.js';
import { AgentService } from '../services/agentService';
import { TransferService } from '../services/transferService';
import { getDb } from '../db';
import { accounts } from '../../drizzle/schema';
import { eq } from 'drizzle-orm';

export const agentRouter = router({
  /**
   * Get agent's current balance.
   */
  getBalance: agentProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const account = await db.select().from(accounts).where(eq(accounts.userId, ctx.user.id)).limit(1);

    return {
      balance: account[0]?.balance || '0',
    };
  }),

  /**
   * Get agent's downline (sub-agents and players).
   */
  getDownline: agentProcedure.query(async ({ ctx }) => {
    const agent = await AgentService.getAgentByUserId(ctx.user.id);
    if (!agent) throw new Error('Agent not found');

    return await AgentService.getDownline(agent.id);
  }),

  /**
   * Get total downline balance.
   */
  getDownlineBalance: agentProcedure.query(async ({ ctx }) => {
    const agent = await AgentService.getAgentByUserId(ctx.user.id);
    if (!agent) throw new Error('Agent not found');

    const balance = await AgentService.getDownlineBalance(agent.id);
    return { balance: balance.toString() };
  }),

  /**
   * Transfer credits to another user.
   */
  transferCredits: agentProcedure
    .input(
      z.object({
        toUserId: z.number(),
        amount: z.number().positive(),
        description: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      await TransferService.transferCredits(
        ctx.user.id,
        input.toUserId,
        new Decimal(input.amount),
        input.description
      );
      return { success: true };
    }),

  /**
   * Get transaction history (sent and received).
   */
  getTransactionHistory: agentProcedure
    .input(
      z.object({
        limit: z.number().default(50),
        offset: z.number().default(0),
      })
    )
    .query(async ({ input, ctx }) => {
      return await TransferService.getTransferHistory(ctx.user.id, input.limit, input.offset);
    }),
});
