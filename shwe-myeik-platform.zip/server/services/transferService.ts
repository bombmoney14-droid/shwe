import Decimal from 'decimal.js';
import { getDb } from '../db';
import { creditTransfers } from '../../drizzle/schema';
import { eq, or, desc } from 'drizzle-orm';
import { LedgerService } from './ledgerService';

/**
 * TransferService: Handles credit transfers between users.
 */

export class TransferService {
  /**
   * Transfer credits from one user to another.
   */
  static async transferCredits(
    fromUserId: number,
    toUserId: number,
    amount: Decimal | number,
    description: string
  ): Promise<void> {
    const decimalAmount = new Decimal(amount);

    // Validate amount
    if (decimalAmount.lessThanOrEqualTo(0)) {
      throw new Error('Transfer amount must be positive');
    }

    // Record in ledger
    await LedgerService.recordTransfer(fromUserId, toUserId, decimalAmount, description);

    // Record in transfer table
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    await db.insert(creditTransfers).values({
      fromUserId,
      toUserId,
      amount: decimalAmount.toString(),
      description,
    });
  }

  /**
   * Get transfer history for a user (sent and received).
   */
  static async getTransferHistory(userId: number, limit: number = 50, offset: number = 0) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    return await db
      .select()
      .from(creditTransfers)
      .where(or(eq(creditTransfers.fromUserId, userId), eq(creditTransfers.toUserId, userId)))
      .orderBy(desc(creditTransfers.createdAt))
      .limit(limit)
      .offset(offset);
  }

  /**
   * Get sent transfers only.
   */
  static async getSentTransfers(userId: number, limit: number = 50, offset: number = 0) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    return await db
      .select()
      .from(creditTransfers)
      .where(eq(creditTransfers.fromUserId, userId))
      .orderBy(desc(creditTransfers.createdAt))
      .limit(limit)
      .offset(offset);
  }

  /**
   * Get received transfers only.
   */
  static async getReceivedTransfers(userId: number, limit: number = 50, offset: number = 0) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    return await db
      .select()
      .from(creditTransfers)
      .where(eq(creditTransfers.toUserId, userId))
      .orderBy(desc(creditTransfers.createdAt))
      .limit(limit)
      .offset(offset);
  }
}
