import Decimal from 'decimal.js';
import { getDb } from '../db';
import { agents, accounts, users } from '../../drizzle/schema';
import { eq } from 'drizzle-orm';

/**
 * AgentService: Manages agent hierarchy and downline relationships.
 */

export class AgentService {
  /**
   * Create a new agent under a parent agent (or at root level).
   */
  static async createAgent(
    userId: number,
    parentAgentId?: number,
    commissionRate: number = 0
  ): Promise<void> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    // Check if agent already exists
    const existing = await db.select().from(agents).where(eq(agents.userId, userId)).limit(1);
    if (existing.length > 0) {
      throw new Error('User is already an agent');
    }

    // Create agent record
    await db.insert(agents).values({
      userId,
      parentAgentId: parentAgentId || null,
      commissionRate: new Decimal(commissionRate).toString(),
    });

    // Ensure account exists
    const account = await db.select().from(accounts).where(eq(accounts.userId, userId)).limit(1);
    if (account.length === 0) {
      await db.insert(accounts).values({
        userId,
        balance: '0',
      });
    }
  }

  /**
   * Get all agents with their balances.
   */
  static async getAllAgents() {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const agentList = await db.select().from(agents);
    const result: any[] = [];

    for (const agent of agentList) {
      const user = await db.select().from(users).where(eq(users.id, agent.userId)).limit(1);
      const account = await db.select().from(accounts).where(eq(accounts.userId, agent.userId)).limit(1);

      result.push({
        ...agent,
        user: user[0] || null,
        balance: account[0]?.balance || '0',
      });
    }

    return result;
  }

  /**
   * Get downline (sub-agents and players) for an agent.
   */
  static async getDownline(agentId: number) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    // Get the agent's user ID
    const agent = await db.select().from(agents).where(eq(agents.id, agentId)).limit(1);
    if (agent.length === 0) throw new Error('Agent not found');

    const agentUserId = agent[0].userId;

    // Get all sub-agents (direct children)
    const subAgents = await db.select().from(agents).where(eq(agents.parentAgentId, agentId));

    // Get all players (for MVP, this is simplified - in production, you'd track player-agent relationships)
    const allPlayers = await db
      .select()
      .from(users)
      .where(eq(users.role, 'player'));

    const result: any = {
      subAgents: [],
      players: [],
    };

    for (const subAgent of subAgents) {
      const user = await db.select().from(users).where(eq(users.id, subAgent.userId)).limit(1);
      const account = await db.select().from(accounts).where(eq(accounts.userId, subAgent.userId)).limit(1);

      result.subAgents.push({
        ...subAgent,
        user: user[0] || null,
        balance: account[0]?.balance || '0',
      });
    }

    for (const player of allPlayers) {
      const account = await db.select().from(accounts).where(eq(accounts.userId, player.id)).limit(1);

      result.players.push({
        user: player,
        balance: account[0]?.balance || '0',
      });
    }

    return result;
  }

  /**
   * Get total downline balance (sum of all sub-agents and players).
   */
  static async getDownlineBalance(agentId: number): Promise<Decimal> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const downline = await this.getDownline(agentId);
    let total = new Decimal(0);

    for (const subAgent of downline.subAgents) {
      total = total.plus(new Decimal(subAgent.balance));
    }

    for (const player of downline.players) {
      total = total.plus(new Decimal(player.balance));
    }

    return total;
  }

  /**
   * Get agent by user ID.
   */
  static async getAgentByUserId(userId: number) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const agent = await db.select().from(agents).where(eq(agents.userId, userId)).limit(1);
    return agent.length > 0 ? agent[0] : null;
  }
}
