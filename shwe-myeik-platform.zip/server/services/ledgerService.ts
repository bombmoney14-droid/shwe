import Decimal from 'decimal.js';
import { getDb } from '../db';
import { accounts, journalEntries, journalLines } from '../../drizzle/schema';
import { eq, desc } from 'drizzle-orm';

/**
 * LedgerService: Double-entry bookkeeping for all credit movements.
 * Every transaction creates balanced journal entries with debit and credit lines.
 */

export class LedgerService {
  /**
   * Validate that an account has sufficient balance for a deduction.
   */
  static async validateBalance(userId: number, amount: Decimal | number): Promise<boolean> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const account = await db
      .select()
      .from(accounts)
      .where(eq(accounts.userId, userId))
      .limit(1);

    if (account.length === 0) return false;

    const balance = new Decimal(account[0].balance);
    const deductAmount = new Decimal(amount);

    return balance.greaterThanOrEqualTo(deductAmount);
  }

  /**
   * Create a journal entry with balanced debit/credit lines.
   * Returns the created entry ID.
   */
  static async createJournalEntry(
    entryType: 'MINT' | 'TRANSFER' | 'BET' | 'WIN',
    description: string,
    lines: Array<{ accountId: number; debit: Decimal | number; credit: Decimal | number }>
  ): Promise<number> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    // Validate balanced entry
    let totalDebit = new Decimal(0);
    let totalCredit = new Decimal(0);

    for (const line of lines) {
      totalDebit = totalDebit.plus(new Decimal(line.debit));
      totalCredit = totalCredit.plus(new Decimal(line.credit));
    }

    if (!totalDebit.equals(totalCredit)) {
      throw new Error('Journal entry not balanced');
    }

    // Insert entry
    await db.insert(journalEntries).values({
      entryType,
      description,
    });

    // Get the inserted entry ID using a reliable method - query by type and description, order by id DESC
    const insertedEntries = await db
      .select()
      .from(journalEntries)
      .where(eq(journalEntries.description, description))
      .orderBy(desc(journalEntries.id))
      .limit(1);

    if (insertedEntries.length === 0) {
      throw new Error('Failed to retrieve inserted entry');
    }

    const entryId = insertedEntries[0].id;

    // Insert lines
    for (const line of lines) {
      await db.insert(journalLines).values({
        entryId,
        accountId: line.accountId,
        debit: new Decimal(line.debit).toString(),
        credit: new Decimal(line.credit).toString(),
      });

      // Update account balance
      const account = await db
        .select()
        .from(accounts)
        .where(eq(accounts.id, line.accountId))
        .limit(1);

      if (account.length > 0) {
        const currentBalance = new Decimal(account[0].balance);
        const debitAmount = new Decimal(line.debit);
        const creditAmount = new Decimal(line.credit);
        const newBalance = currentBalance.minus(debitAmount).plus(creditAmount);

        await db
          .update(accounts)
          .set({ balance: newBalance.toString() })
          .where(eq(accounts.id, account[0].id));
      }
    }

    return entryId;
  }

  /**
   * Record a credit mint (admin only).
   */
  static async recordMint(adminUserId: number, amount: Decimal | number, description: string): Promise<number> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    // Get or create admin account
    let adminAccount = await db
      .select()
      .from(accounts)
      .where(eq(accounts.userId, adminUserId))
      .limit(1);

    if (adminAccount.length === 0) {
      await db.insert(accounts).values({
        userId: adminUserId,
        balance: '0',
      });
      adminAccount = await db
        .select()
        .from(accounts)
        .where(eq(accounts.userId, adminUserId))
        .limit(1);
    }

    const decimalAmount = new Decimal(amount);

    return await this.createJournalEntry('MINT', description, [
      {
        accountId: adminAccount[0].id,
        debit: 0,
        credit: decimalAmount,
      },
    ]);
  }

  /**
   * Record a credit transfer between users.
   */
  static async recordTransfer(
    fromUserId: number,
    toUserId: number,
    amount: Decimal | number,
    description: string
  ): Promise<number> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const decimalAmount = new Decimal(amount);

    // Validate sender has sufficient balance
    if (!(await this.validateBalance(fromUserId, decimalAmount))) {
      throw new Error('Insufficient balance');
    }

    // Get or create accounts
    let fromAccount = await db
      .select()
      .from(accounts)
      .where(eq(accounts.userId, fromUserId))
      .limit(1);

    if (fromAccount.length === 0) {
      await db.insert(accounts).values({
        userId: fromUserId,
        balance: '0',
      });
      fromAccount = await db
        .select()
        .from(accounts)
        .where(eq(accounts.userId, fromUserId))
        .limit(1);
    }

    let toAccount = await db
      .select()
      .from(accounts)
      .where(eq(accounts.userId, toUserId))
      .limit(1);

    if (toAccount.length === 0) {
      await db.insert(accounts).values({
        userId: toUserId,
        balance: '0',
      });
      toAccount = await db
        .select()
        .from(accounts)
        .where(eq(accounts.userId, toUserId))
        .limit(1);
    }

    return await this.createJournalEntry('TRANSFER', description, [
      {
        accountId: fromAccount[0].id,
        debit: decimalAmount,
        credit: 0,
      },
      {
        accountId: toAccount[0].id,
        debit: 0,
        credit: decimalAmount,
      },
    ]);
  }

  /**
   * Record a bet placement (debit from player account).
   */
  static async recordBet(userId: number, amount: Decimal | number, gameId: number): Promise<number> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const decimalAmount = new Decimal(amount);

    // Validate player has sufficient balance
    if (!(await this.validateBalance(userId, decimalAmount))) {
      throw new Error('Insufficient balance');
    }

    // Get or create account
    let userAccount = await db
      .select()
      .from(accounts)
      .where(eq(accounts.userId, userId))
      .limit(1);

    if (userAccount.length === 0) {
      await db.insert(accounts).values({
        userId,
        balance: '0',
      });
      userAccount = await db
        .select()
        .from(accounts)
        .where(eq(accounts.userId, userId))
        .limit(1);
    }

    return await this.createJournalEntry('BET', `Bet on game ${gameId}`, [
      {
        accountId: userAccount[0].id,
        debit: decimalAmount,
        credit: 0,
      },
    ]);
  }

  /**
   * Record a win payout (credit to player account).
   */
  static async recordWin(userId: number, amount: Decimal | number, gameId: number): Promise<number> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    const decimalAmount = new Decimal(amount);

    // Get or create account
    let userAccount = await db
      .select()
      .from(accounts)
      .where(eq(accounts.userId, userId))
      .limit(1);

    if (userAccount.length === 0) {
      await db.insert(accounts).values({
        userId,
        balance: '0',
      });
      userAccount = await db
        .select()
        .from(accounts)
        .where(eq(accounts.userId, userId))
        .limit(1);
    }

    return await this.createJournalEntry('WIN', `Win on game ${gameId}`, [
      {
        accountId: userAccount[0].id,
        debit: 0,
        credit: decimalAmount,
      },
    ]);
  }

  /**
   * Get journal entries with optional filtering.
   */
  static async getJournalEntries(
    entryType?: 'MINT' | 'TRANSFER' | 'BET' | 'WIN',
    limit: number = 50,
    offset: number = 0
  ) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    let query = db.select().from(journalEntries);

    if (entryType) {
      query = query.where(eq(journalEntries.entryType, entryType)) as any;
    }

    const result = await (query as any).orderBy(desc(journalEntries.id)).limit(limit).offset(offset);
    return result;
  }

  /**
   * Get journal lines for an entry.
   */
  static async getJournalLines(entryId: number) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    return await db.select().from(journalLines).where(eq(journalLines.entryId, entryId));
  }
}
