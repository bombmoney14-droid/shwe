import Decimal from 'decimal.js';
import { getDb } from '../db';
import { journalEntries } from '../../drizzle/schema';
import { eq, desc } from 'drizzle-orm';
import { LedgerService } from './ledgerService';

/**
 * CreditMintService: Handles admin credit minting (creation of new credits).
 */

export class CreditMintService {
  /**
   * Mint new credits to an admin account.
   */
  static async mintCredits(adminUserId: number, amount: Decimal | number, description: string): Promise<number> {
    const decimalAmount = new Decimal(amount);

    // Validate amount
    if (decimalAmount.lessThanOrEqualTo(0)) {
      throw new Error('Mint amount must be positive');
    }

    // Record in ledger
    const entryId = await LedgerService.recordMint(adminUserId, decimalAmount, description);

    return entryId;
  }

  /**
   * Get mint history (all MINT entries).
   */
  static async getMintHistory(limit: number = 50, offset: number = 0) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    return await db
      .select()
      .from(journalEntries)
      .where(eq(journalEntries.entryType, 'MINT'))
      .orderBy(desc(journalEntries.id))
      .limit(limit)
      .offset(offset);
  }
}
