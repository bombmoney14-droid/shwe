import Decimal from 'decimal.js';
import { getDb } from '../db';
import { gameHistory } from '../../drizzle/schema';
import { eq, desc } from 'drizzle-orm';
import { LedgerService } from './ledgerService';

/**
 * GameEngineService: Handles game mechanics and history tracking.
 */

export class GameEngineService {
  /**
   * Play Min Tone Min game: best of 3 rounds, player vs house.
   * Returns game result with all round data.
   */
  static async playMinToneMin(userId: number, gameId: number, betAmount: Decimal | number) {
    const decimalBet = new Decimal(betAmount);

    // Record bet
    await LedgerService.recordBet(userId, decimalBet, gameId);

    // Play 3 rounds
    const rounds = [];
    let playerWins = 0;
    let houseWins = 0;

    for (let i = 0; i < 3; i++) {
      const playerCard = Math.floor(Math.random() * 13) + 1;
      const houseCard = Math.floor(Math.random() * 13) + 1;

      const roundWinner = playerCard > houseCard ? 'player' : houseCard > playerCard ? 'house' : 'tie';

      if (roundWinner === 'player') playerWins++;
      if (roundWinner === 'house') houseWins++;

      rounds.push({
        roundNumber: i + 1,
        playerCard,
        houseCard,
        winner: roundWinner,
      });
    }

    const gameResult = playerWins > houseWins ? 'WIN' : 'LOSE';
    const winAmount = gameResult === 'WIN' ? decimalBet.times(2) : new Decimal(0);

    // Record win if applicable
    if (gameResult === 'WIN') {
      await LedgerService.recordWin(userId, winAmount, gameId);
    }

    // Record in game history
    await this.recordGameHistory(userId, gameId, decimalBet, winAmount, gameResult, {
      rounds,
      playerWins,
      houseWins,
    });

    return {
      result: gameResult,
      rounds,
      playerWins,
      houseWins,
      betAmount: decimalBet.toString(),
      winAmount: winAmount.toString(),
    };
  }

  /**
   * Play Mini Slot game: 3-reel slot machine.
   * Returns game result with reel values.
   */
  static async playMiniSlot(userId: number, gameId: number, betAmount: Decimal | number) {
    const decimalBet = new Decimal(betAmount);

    // Record bet
    await LedgerService.recordBet(userId, decimalBet, gameId);

    // Spin 3 reels
    const symbols = ['🌸', '💎', '🏆', '⭐', '🎋', '🦁'];
    const reel1 = symbols[Math.floor(Math.random() * symbols.length)];
    const reel2 = symbols[Math.floor(Math.random() * symbols.length)];
    const reel3 = symbols[Math.floor(Math.random() * symbols.length)];

    // Determine win condition
    let multiplier = 0;
    if (reel1 === reel2 && reel2 === reel3) {
      multiplier = 2; // 3-match = 2x
    } else if (reel1 === reel2 || reel2 === reel3 || reel1 === reel3) {
      multiplier = 1.5; // 2-match = 1.5x
    }

    const gameResult = multiplier > 0 ? 'WIN' : 'LOSE';
    const winAmount = multiplier > 0 ? decimalBet.times(multiplier) : new Decimal(0);

    // Record win if applicable
    if (gameResult === 'WIN') {
      await LedgerService.recordWin(userId, winAmount, gameId);
    }

    // Record in game history
    await this.recordGameHistory(userId, gameId, decimalBet, winAmount, gameResult, {
      reels: [reel1, reel2, reel3],
      multiplier,
    });

    return {
      result: gameResult,
      reels: [reel1, reel2, reel3],
      multiplier,
      betAmount: decimalBet.toString(),
      winAmount: winAmount.toString(),
    };
  }

  /**
   * Record game play in history.
   */
  static async recordGameHistory(
    userId: number,
    gameId: number,
    betAmount: Decimal | number,
    winAmount: Decimal | number,
    result: 'WIN' | 'LOSE',
    gameData: any
  ): Promise<void> {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    await db.insert(gameHistory).values({
      userId,
      gameId,
      betAmount: new Decimal(betAmount).toString(),
      winAmount: new Decimal(winAmount).toString(),
      result,
      gameData: JSON.stringify(gameData),
    });
  }

  /**
   * Get game history for a player.
   */
  static async getGameHistory(userId: number, limit: number = 50, offset: number = 0) {
    const db = await getDb();
    if (!db) throw new Error('Database not available');

    return await db
      .select()
      .from(gameHistory)
      .where(eq(gameHistory.userId, userId))
      .orderBy(desc(gameHistory.createdAt))
      .limit(limit)
      .offset(offset);
  }
}
