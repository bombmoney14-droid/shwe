import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";

import PlayerLogin from "./pages/PlayerLogin";
import PlayerRegister from "./pages/PlayerRegister";
import LocalMiniSlot from "./pages/LocalMiniSlot";
import PlayerDashboard from "./pages/PlayerDashboard";
import KioskLogin from "./pages/KioskLogin";
import KioskDashboard from "./pages/KioskDashboard";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/ "} component={Home} />
      <Route path={"/login"} component={PlayerLogin} />
      <Route path={"/register"} component={PlayerRegister} />
      <Route path={"/game/mini-slot"} component={LocalMiniSlot} />
      <Route path={"/dashboard"} component={PlayerDashboard} />
      <Route path={"/kiosk/login"} component={KioskLogin} />
      <Route path={"/kiosk/dashboard"} component={KioskDashboard} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="dark"
        switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
