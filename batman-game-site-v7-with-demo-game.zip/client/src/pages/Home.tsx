import { useState, useEffect } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, LogOut, User, LogIn } from "lucide-react";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { Link, useLocation } from "wouter";

const GAME_CATEGORIES = [
  "Slot",
  "Game Show",
  "Buffalo",
  "Arcade",
  "Live",
  "Fish",
  "Sport",
  "Lottery",
];

export default function Home() {
  const { user, loading, isAuthenticated, logout } = useAuth();
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [, setLocation] = useLocation();

  const categoriesQuery = trpc.game.getCategories.useQuery();
  const gamesQuery = trpc.game.getGamesByCategory.useQuery(
    { categoryId: selectedCategory ? parseInt(selectedCategory) : 0 },
    { enabled: !!selectedCategory }
  );

  useEffect(() => {
    if (GAME_CATEGORIES.length > 0) {
      setSelectedCategory(GAME_CATEGORIES[0]);
    }
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="animate-spin text-accent w-8 h-8" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border/50 bg-background/95 backdrop-blur-sm">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-to-br from-accent to-accent/60 rounded-lg flex items-center justify-center">
              <span className="text-accent-foreground font-bold text-lg">PZ</span>
            </div>
            <h1 className="text-xl font-bold text-accent">Play Zone</h1>
          </div>

          <div className="flex items-center gap-4">
            {isAuthenticated ? (
              <>
                <Link href="/dashboard">
                  <Button variant="outline" size="sm" className="gap-2">
                    <User className="w-4 h-4" />
                    Dashboard
                  </Button>
                </Link>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    logout();
                    setLocation("/");
                  }}
                  className="gap-2"
                >
                  <LogOut className="w-4 h-4" />
                  Logout
                </Button>
              </>
            ) : (
              <>
                <Link href="/login">
                  <Button variant="outline" size="sm" className="gap-2">
                    <LogIn className="w-4 h-4" />
                    Login
                  </Button>
                </Link>
                <Link href="/register">
                  <Button size="sm" className="btn-premium">
                    Register
                  </Button>
                </Link>
              </>
            )}
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-12 md:py-20">
        <div className="absolute inset-0 bg-gradient-to-br from-accent/10 via-transparent to-transparent" />
        <div className="container relative z-10">
          <div className="max-w-2xl">
            <h2 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">
              Welcome to <span className="text-accent">Play Zone</span>
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              Experience premium gaming with our collection of exciting games across multiple categories. Secure, fair, and thrilling gameplay awaits.
            </p>
            {!isAuthenticated && (
              <div className="flex gap-4">
                <Link href="/register">
                  <Button className="btn-premium">Get Started</Button>
                </Link>
                <Link href="/login">
                  <Button variant="outline" className="btn-outline-premium">
                    Sign In
                  </Button>
                </Link>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Category Navigation */}
      <section className="border-t border-b border-border/50 bg-card/50">
        <div className="container">
          <div className="flex overflow-x-auto gap-2 py-4 scrollbar-hide">
            {GAME_CATEGORIES.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-6 py-2 rounded-lg font-semibold whitespace-nowrap transition-all duration-200 ${
                  selectedCategory === category
                    ? "bg-accent text-accent-foreground shadow-lg shadow-accent/30"
                    : "bg-muted text-muted-foreground hover:bg-muted/80"
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Games Grid */}
      <section className="py-12 md:py-16">
        <div className="container">
          <h3 className="text-2xl md:text-3xl font-bold mb-8 text-foreground">
            {selectedCategory} Games
          </h3>

          {gamesQuery.isLoading ? (
            <div className="flex justify-center items-center py-12">
              <Loader2 className="animate-spin text-accent w-8 h-8" />
            </div>
          ) : gamesQuery.data && gamesQuery.data.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
              {gamesQuery.data.map((game) => (
                <Card
                  key={game.id}
                  className="game-card group overflow-hidden cursor-pointer"
                >
                  {/* Game Image Placeholder */}
                  <div className="relative w-full aspect-video bg-gradient-to-br from-accent/20 to-accent/5 flex items-center justify-center overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent" />
                    <div className="relative z-10 text-center">
                      <div className="text-4xl font-bold text-accent/40 group-hover:text-accent/60 transition-colors">
                        {game.name.charAt(0)}
                      </div>
                    </div>
                  </div>

                  {/* Game Info */}
                  <div className="p-4">
                    <h4 className="font-semibold text-foreground mb-2 line-clamp-2">
                      {game.name}
                    </h4>
                    {game.description && (
                      <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                        {game.description}
                      </p>
                    )}

                    {/* Play Button */}
                    {isAuthenticated ? (
                      <Button className="w-full btn-premium" size="sm">
                        Play Now
                      </Button>
                    ) : (
                      <Link href="/login">
                        <Button className="w-full btn-premium" size="sm">
                          Login to Play
                        </Button>
                      </Link>
                    )}
                  </div>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No games available in this category yet.</p>
            </div>
          )}
        </div>
      </section>

      {/* Features Section */}
      <section className="py-12 md:py-16 bg-card/50 border-t border-border/50">
        <div className="container">
          <h3 className="text-2xl md:text-3xl font-bold mb-12 text-center text-foreground">
            Why Choose Play Zone?
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                title: "Secure & Fair",
                description: "Industry-leading security and provably fair gaming",
              },
              {
                title: "Multiple Categories",
                description: "8 diverse game categories to suit every preference",
              },
              {
                title: "Premium Experience",
                description: "Smooth gameplay with responsive design on all devices",
              },
            ].map((feature, idx) => (
              <Card key={idx} className="p-6 border-accent/20 hover:border-accent/50 transition-colors">
                <h4 className="font-semibold text-lg text-accent mb-2">{feature.title}</h4>
                <p className="text-muted-foreground">{feature.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 py-8 bg-background">
        <div className="container">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-accent to-accent/60 rounded-lg flex items-center justify-center">
                <span className="text-accent-foreground font-bold">PZ</span>
              </div>
              <span className="font-semibold text-accent">Play Zone</span>
            </div>
            <p className="text-sm text-muted-foreground">
              © 2026 Play Zone. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
