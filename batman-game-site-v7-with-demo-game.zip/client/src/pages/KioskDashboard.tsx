import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, LogOut, Users, CreditCard, ArrowUp, ArrowDown } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function KioskDashboard() {
  const [, setLocation] = useLocation();
  const [agentId] = useState(1); // This would come from session/context
  const [activeTab, setActiveTab] = useState("players");
  const [topupPlayerId, setTopupPlayerId] = useState("");
  const [topupAmount, setTopupAmount] = useState("");
  const [withdrawPlayerId, setWithdrawPlayerId] = useState("");
  const [withdrawAmount, setWithdrawAmount] = useState("");

  const playersQuery = trpc.agent.tools.getPlayerList.useQuery({ limit: 50 });
  const transactionsQuery = trpc.agent.tools.getTransactionHistory.useQuery({ limit: 50 });

  const topupMutation = trpc.agent.tools.topupCredit.useMutation({
    onSuccess: () => {
      toast.success("Credit top-up successful!");
      setTopupPlayerId("");
      setTopupAmount("");
      playersQuery.refetch();
      transactionsQuery.refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Top-up failed");
    },
  });

  const withdrawalMutation = trpc.agent.tools.processWithdrawal.useMutation({
    onSuccess: () => {
      toast.success("Withdrawal processed successfully!");
      setWithdrawPlayerId("");
      setWithdrawAmount("");
      playersQuery.refetch();
      transactionsQuery.refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Withdrawal failed");
    },
  });

  const logoutMutation = trpc.agent.auth.logout.useMutation({
    onSuccess: () => {
      toast.success("Logged out successfully");
      setLocation("/kiosk/login");
    },
  });

  const handleTopup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topupPlayerId || !topupAmount) {
      toast.error("Please fill in all fields");
      return;
    }
    await topupMutation.mutateAsync({
      playerId: parseInt(topupPlayerId),
      amount: topupAmount,
      agentId,
    });
  };

  const handleWithdrawal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!withdrawPlayerId || !withdrawAmount) {
      toast.error("Please fill in all fields");
      return;
    }
    await withdrawalMutation.mutateAsync({
      playerId: parseInt(withdrawPlayerId),
      amount: withdrawAmount,
      agentId,
    });
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/50">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-to-br from-accent to-accent/60 rounded-lg flex items-center justify-center">
              <span className="text-accent-foreground font-bold">PZ</span>
            </div>
            <h1 className="text-xl font-bold text-accent">Play Zone Kiosk</h1>
          </div>

          <Button
            variant="outline"
            size="sm"
            onClick={handleLogout}
            className="gap-2"
          >
            <LogOut className="w-4 h-4" />
            Logout
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="players">Player Management</TabsTrigger>
            <TabsTrigger value="topup">Credit Top-up</TabsTrigger>
            <TabsTrigger value="withdrawal">Withdrawals</TabsTrigger>
          </TabsList>

          {/* Player Management Tab */}
          <TabsContent value="players" className="space-y-6">
            <Card className="p-6 border-accent/20">
              <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
                <Users className="w-5 h-5" />
                Player List
              </h3>

              {playersQuery.isLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="animate-spin text-accent w-6 h-6" />
                </div>
              ) : playersQuery.data && playersQuery.data.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="border-b border-border/50">
                      <tr>
                        <th className="text-left py-3 text-muted-foreground font-medium">
                          ID
                        </th>
                        <th className="text-left py-3 text-muted-foreground font-medium">
                          Username
                        </th>
                        <th className="text-left py-3 text-muted-foreground font-medium">
                          Balance
                        </th>
                        <th className="text-left py-3 text-muted-foreground font-medium">
                          Points
                        </th>
                        <th className="text-left py-3 text-muted-foreground font-medium">
                          Status
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {playersQuery.data.map((player) => (
                        <tr
                          key={player.id}
                          className="border-b border-border/50 hover:bg-muted/50 transition-colors"
                        >
                          <td className="py-3 text-foreground">{player.id}</td>
                          <td className="py-3 text-foreground font-semibold">
                            {player.username}
                          </td>
                          <td className="py-3 text-foreground">
                            ${player.balance}
                          </td>
                          <td className="py-3 text-foreground">
                            {player.points}
                          </td>
                          <td className="py-3">
                            <span
                              className={`px-2 py-1 rounded text-xs font-semibold ${
                                player.status === "active"
                                  ? "bg-green-500/20 text-green-400"
                                  : "bg-red-500/20 text-red-400"
                              }`}
                            >
                              {player.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <p className="text-center py-8 text-muted-foreground">
                  No players found
                </p>
              )}
            </Card>
          </TabsContent>

          {/* Credit Top-up Tab */}
          <TabsContent value="topup" className="space-y-6">
            <Card className="p-6 border-accent/20">
              <h3 className="text-lg font-semibold text-foreground mb-6 flex items-center gap-2">
                <ArrowUp className="w-5 h-5 text-green-500" />
                Credit Top-up
              </h3>

              <form onSubmit={handleTopup} className="space-y-4 max-w-md">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Player ID
                  </label>
                  <Input
                    type="number"
                    placeholder="Enter player ID"
                    value={topupPlayerId}
                    onChange={(e) => setTopupPlayerId(e.target.value)}
                    disabled={topupMutation.isPending}
                    className="bg-input border-border/50 text-foreground"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Amount ($)
                  </label>
                  <Input
                    type="number"
                    placeholder="Enter amount"
                    step="0.01"
                    value={topupAmount}
                    onChange={(e) => setTopupAmount(e.target.value)}
                    disabled={topupMutation.isPending}
                    className="bg-input border-border/50 text-foreground"
                  />
                </div>

                <Button
                  type="submit"
                  disabled={topupMutation.isPending}
                  className="w-full btn-premium"
                >
                  {topupMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                      Processing...
                    </>
                  ) : (
                    "Process Top-up"
                  )}
                </Button>
              </form>
            </Card>
          </TabsContent>

          {/* Withdrawal Tab */}
          <TabsContent value="withdrawal" className="space-y-6">
            <Card className="p-6 border-accent/20">
              <h3 className="text-lg font-semibold text-foreground mb-6 flex items-center gap-2">
                <ArrowDown className="w-5 h-5 text-red-500" />
                Process Withdrawal
              </h3>

              <form onSubmit={handleWithdrawal} className="space-y-4 max-w-md">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Player ID
                  </label>
                  <Input
                    type="number"
                    placeholder="Enter player ID"
                    value={withdrawPlayerId}
                    onChange={(e) => setWithdrawPlayerId(e.target.value)}
                    disabled={withdrawalMutation.isPending}
                    className="bg-input border-border/50 text-foreground"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Amount ($)
                  </label>
                  <Input
                    type="number"
                    placeholder="Enter amount"
                    step="0.01"
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(e.target.value)}
                    disabled={withdrawalMutation.isPending}
                    className="bg-input border-border/50 text-foreground"
                  />
                </div>

                <Button
                  type="submit"
                  disabled={withdrawalMutation.isPending}
                  className="w-full btn-premium"
                >
                  {withdrawalMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin mr-2" />
                      Processing...
                    </>
                  ) : (
                    "Process Withdrawal"
                  )}
                </Button>
              </form>
            </Card>

            {/* Transaction History */}
            <Card className="p-6 border-accent/20">
              <h3 className="text-lg font-semibold text-foreground mb-4">
                Recent Transactions
              </h3>

              {transactionsQuery.isLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="animate-spin text-accent w-6 h-6" />
                </div>
              ) : transactionsQuery.data && transactionsQuery.data.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="border-b border-border/50">
                      <tr>
                        <th className="text-left py-3 text-muted-foreground font-medium">
                          Player ID
                        </th>
                        <th className="text-left py-3 text-muted-foreground font-medium">
                          Type
                        </th>
                        <th className="text-left py-3 text-muted-foreground font-medium">
                          Amount
                        </th>
                        <th className="text-left py-3 text-muted-foreground font-medium">
                          Status
                        </th>
                        <th className="text-left py-3 text-muted-foreground font-medium">
                          Date
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {transactionsQuery.data.map((transaction) => (
                        <tr
                          key={transaction.id}
                          className="border-b border-border/50 hover:bg-muted/50 transition-colors"
                        >
                          <td className="py-3 text-foreground">
                            {transaction.playerId}
                          </td>
                          <td className="py-3">
                            <span className="px-2 py-1 rounded text-xs font-semibold bg-accent/20 text-accent capitalize">
                              {transaction.type}
                            </span>
                          </td>
                          <td className="py-3 text-foreground">
                            ${transaction.amount}
                          </td>
                          <td className="py-3">
                            <span
                              className={`px-2 py-1 rounded text-xs font-semibold ${
                                transaction.status === "completed"
                                  ? "bg-green-500/20 text-green-400"
                                  : "bg-yellow-500/20 text-yellow-400"
                              }`}
                            >
                              {transaction.status}
                            </span>
                          </td>
                          <td className="py-3 text-muted-foreground">
                            {new Date(transaction.createdAt).toLocaleDateString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <p className="text-center py-8 text-muted-foreground">
                  No transactions yet
                </p>
              )}
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
