import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, LogOut, Lock, Wallet, TrendingUp, History } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function PlayerDashboard() {
  const [, setLocation] = useLocation();
  const [playerId] = useState(1); // This would come from session/context
  const [activeTab, setActiveTab] = useState("overview");

  const profileQuery = trpc.player.dashboard.getProfile.useQuery({ playerId });
  const historyQuery = trpc.player.dashboard.getGameHistory.useQuery({ playerId, limit: 10 });
  const transactionsQuery = trpc.player.dashboard.getTransactionHistory.useQuery({ playerId, limit: 10 });

  const logoutMutation = trpc.player.auth.logout.useMutation({
    onSuccess: () => {
      toast.success("Logged out successfully");
      setLocation("/");
    },
  });

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  if (profileQuery.isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="animate-spin text-accent w-8 h-8" />
      </div>
    );
  }

  const profile = profileQuery.data;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/50">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-to-br from-accent to-accent/60 rounded-lg flex items-center justify-center">
              <span className="text-accent-foreground font-bold">PZ</span>
            </div>
            <h1 className="text-xl font-bold text-accent">Play Zone</h1>
          </div>

          <Button
            variant="outline"
            size="sm"
            onClick={handleLogout}
            className="gap-2"
          >
            <LogOut className="w-4 h-4" />
            Logout
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {/* Balance Card */}
          <Card className="p-6 border-accent/20 bg-gradient-accent">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-medium text-muted-foreground">
                Account Balance
              </h3>
              <Wallet className="w-5 h-5 text-accent" />
            </div>
            <div className="text-3xl font-bold text-foreground">
              ${profile?.balance || "0.00"}
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              Available for play
            </p>
          </Card>

          {/* Points Card */}
          <Card className="p-6 border-accent/20 bg-gradient-accent">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-medium text-muted-foreground">
                Loyalty Points
              </h3>
              <TrendingUp className="w-5 h-5 text-accent" />
            </div>
            <div className="text-3xl font-bold text-foreground">
              {profile?.points || "0"}
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              Earn more by playing
            </p>
          </Card>

          {/* Status Card */}
          <Card className="p-6 border-accent/20 bg-gradient-accent">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-medium text-muted-foreground">
                Account Status
              </h3>
              <div className="w-3 h-3 bg-green-500 rounded-full" />
            </div>
            <div className="text-3xl font-bold text-foreground capitalize">
              {profile?.status || "Active"}
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              Account is active
            </p>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="history">Game History</TabsTrigger>
            <TabsTrigger value="transactions">Transactions</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <Card className="p-6 border-accent/20">
              <h3 className="text-lg font-semibold text-foreground mb-4">
                Account Information
              </h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center pb-4 border-b border-border/50">
                  <span className="text-muted-foreground">Username</span>
                  <span className="font-semibold text-foreground">
                    {profile?.username}
                  </span>
                </div>
                <div className="flex justify-between items-center pb-4 border-b border-border/50">
                  <span className="text-muted-foreground">Member Since</span>
                  <span className="font-semibold text-foreground">
                    {profile?.createdAt
                      ? new Date(profile.createdAt).toLocaleDateString()
                      : "N/A"}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Last Login</span>
                  <span className="font-semibold text-foreground">
                    {profile?.updatedAt
                      ? new Date(profile.updatedAt).toLocaleDateString()
                      : "N/A"}
                  </span>
                </div>
              </div>

              {/* Security Section */}
              <div className="mt-8 pt-6 border-t border-border/50">
                <h4 className="font-semibold text-foreground mb-4 flex items-center gap-2">
                  <Lock className="w-4 h-4" />
                  Security
                </h4>
                <Button
                  variant="outline"
                  className="btn-outline-premium"
                  onClick={() => setLocation("/change-password")}
                >
                  Change Password
                </Button>
              </div>
            </Card>
          </TabsContent>

          {/* Game History Tab */}
          <TabsContent value="history">
            <Card className="p-6 border-accent/20">
              <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
                <History className="w-5 h-5" />
                Recent Game History
              </h3>

              {historyQuery.isLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="animate-spin text-accent w-6 h-6" />
                </div>
              ) : historyQuery.data && historyQuery.data.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="border-b border-border/50">
                      <tr>
                        <th className="text-left py-3 text-muted-foreground font-medium">
                          Game ID
                        </th>
                        <th className="text-left py-3 text-muted-foreground font-medium">
                          Bet Amount
                        </th>
                        <th className="text-left py-3 text-muted-foreground font-medium">
                          Win Amount
                        </th>
                        <th className="text-left py-3 text-muted-foreground font-medium">
                          Status
                        </th>
                        <th className="text-left py-3 text-muted-foreground font-medium">
                          Date
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {historyQuery.data.map((record) => (
                        <tr
                          key={record.id}
                          className="border-b border-border/50 hover:bg-muted/50 transition-colors"
                        >
                          <td className="py-3 text-foreground">{record.gameId}</td>
                          <td className="py-3 text-foreground">
                            ${record.betAmount}
                          </td>
                          <td className="py-3 text-foreground">
                            ${record.winAmount}
                          </td>
                          <td className="py-3">
                            <span
                              className={`px-2 py-1 rounded text-xs font-semibold ${
                                record.status === "completed"
                                  ? "bg-green-500/20 text-green-400"
                                  : "bg-yellow-500/20 text-yellow-400"
                              }`}
                            >
                              {record.status}
                            </span>
                          </td>
                          <td className="py-3 text-muted-foreground">
                            {new Date(record.createdAt).toLocaleDateString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <p className="text-center py-8 text-muted-foreground">
                  No game history yet
                </p>
              )}
            </Card>
          </TabsContent>

          {/* Transactions Tab */}
          <TabsContent value="transactions">
            <Card className="p-6 border-accent/20">
              <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
                <Wallet className="w-5 h-5" />
                Transaction History
              </h3>

              {transactionsQuery.isLoading ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="animate-spin text-accent w-6 h-6" />
                </div>
              ) : transactionsQuery.data && transactionsQuery.data.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="border-b border-border/50">
                      <tr>
                        <th className="text-left py-3 text-muted-foreground font-medium">
                          Type
                        </th>
                        <th className="text-left py-3 text-muted-foreground font-medium">
                          Amount
                        </th>
                        <th className="text-left py-3 text-muted-foreground font-medium">
                          Status
                        </th>
                        <th className="text-left py-3 text-muted-foreground font-medium">
                          Description
                        </th>
                        <th className="text-left py-3 text-muted-foreground font-medium">
                          Date
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {transactionsQuery.data.map((transaction) => (
                        <tr
                          key={transaction.id}
                          className="border-b border-border/50 hover:bg-muted/50 transition-colors"
                        >
                          <td className="py-3">
                            <span className="px-2 py-1 rounded text-xs font-semibold bg-accent/20 text-accent capitalize">
                              {transaction.type}
                            </span>
                          </td>
                          <td className="py-3 text-foreground">
                            ${transaction.amount}
                          </td>
                          <td className="py-3">
                            <span
                              className={`px-2 py-1 rounded text-xs font-semibold ${
                                transaction.status === "completed"
                                  ? "bg-green-500/20 text-green-400"
                                  : "bg-yellow-500/20 text-yellow-400"
                              }`}
                            >
                              {transaction.status}
                            </span>
                          </td>
                          <td className="py-3 text-muted-foreground text-xs">
                            {transaction.description}
                          </td>
                          <td className="py-3 text-muted-foreground">
                            {new Date(transaction.createdAt).toLocaleDateString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <p className="text-center py-8 text-muted-foreground">
                  No transactions yet
                </p>
              )}
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
