# 🎮 Game Provider Integration (Pragmatic Play, JILI, etc.)

V7 Architecture တွင် External Game Provider များကို **Seamless Wallet** စနစ်ဖြင့် ချိတ်ဆက်ရန် အောက်ပါအတိုင်း ပြင်ဆင်ထားပါသည်။

---

## 🔗 1. Seamless Wallet (Callback System)
Provider များ (Pragmatic, JILI) သည် Player ၏ Balance ကို စစ်ဆေးရန်နှင့် Bet/Win များအတွက် ကျွန်ုပ်တို့၏ Backend ဆီသို့ API Callbacks များ ပေးပို့ပါမည်။

### Key Endpoints (To be implemented in API Routes):
- `GET /api/callback/balance` - Provider မှ Player ၏ လက်ကျန်ငွေကို စစ်ဆေးခြင်း။
- `POST /api/callback/debit` - Player ဂိမ်းဆော့သည့်အခါ (Bet) ပိုက်ဆံနှုတ်ခြင်း။
- `POST /api/callback/credit` - Player အနိုင်ရသည့်အခါ (Win) ပိုက်ဆံသွင်းပေးခြင်း။

---

## 🛠 2. V7 Seamless Logic
ကျွန်ုပ်တို့၏ `v7_seamless_wallet.ts` သည် Provider ထံမှလာသော Request တိုင်းကို **V7 Ledger** နှင့် တိုက်ရိုက်ချိတ်ဆက်ပေးသည်။

- **Idempotency:** Provider ဆီမှ Transaction ID တစ်ခုတည်းဖြင့် Request နှစ်ခါလာပါက V7 Ledger မှ အလိုအလျောက် သိရှိပြီး Double-debit မဖြစ်အောင် ကာကွယ်ပေးသည်။
- **Atomic Execution:** Bet နှုတ်ခြင်းနှင့် Win သွင်းခြင်းများကို Database level တွင် Atomic ဖြစ်အောင် လုပ်ဆောင်သောကြောင့် ငွေစာရင်း လုံးဝမလွဲနိုင်ပါ။

---

## 🚀 3. Supported Providers (Example)

### Pragmatic Play
- **Integration Type:** Seamless Wallet
- **Currency:** MMK (Supported via V7 Currency Layer)

### JILI
- **Integration Type:** Seamless Wallet
- **Game Types:** Slot, Fishing, Table Games

### Evolution Gaming / Sexy Baccarat (Live Casino)
- **Integration Type:** Seamless Wallet
- **Game Types:** Baccarat, Roulette, Blackjack, Game Shows
- **Status:** Fully supported via V7 Unified Adapter.

---

## 📂 Code References
- **Schema:** `drizzle/schema_v7.ts` (Game Providers & Sessions tables)
- **Logic:** `server/v7_seamless_wallet.ts` (Debit/Credit handling)
