# 🌳 Agent Tree & Credit Minting System (V7)

ဤစနစ်သည် Site Owner (Admin) တစ်ဦးတည်းသာ Credit ထုတ်နိုင်ပြီး၊ ၎င်းမှတစ်ဆင့် Agent များထံသို့ အဆင့်ဆင့် ဖြန့်ဖြူးရောင်းချနိုင်သော Tree Structure ကို အကောင်အထည်ဖော်ထားသည်။

---

## 💎 1. Credit Minting (Money Creation)
- **Constraint:** Admin (Site Owner) တစ်ဦးတည်းသာ လုပ်ဆောင်နိုင်သည်။
- **Mechanism:** `JOURNAL_MINT_EXECUTE` capability ကို စစ်ဆေးပြီးမှသာ Credit အသစ်များကို System Equity Account မှ ထုတ်ပေးသည်။
- **Logic:** `server/v7_agent_service.ts` ရှိ `mintCredit()` function ကို ကြည့်ပါ။

## 🌳 2. Agent Tree Structure
- **Multi-level Hierarchy:** Agent တစ်ဦးစီတွင် `parentId` ရှိပြီး ၎င်းတို့၏အောက်တွင် Agent အသစ်များကို ထပ်ဆင့် တိုးချဲ့နိုင်သည်။
- **Materialized Path:** Tree structure ကို မြန်ဆန်စွာ ရှာဖွေနိုင်ရန် `path` (ဥပမာ- `/1/5/12/`) ကို အသုံးပြုထားသည်။
- **Logic:** `agent_hierarchy` table နှင့် `createAgent()` function ကို ကြည့်ပါ။

## 💸 3. Credit Distribution (Transfer)
- **Flow:** Admin → Master Agent → Sub-Agent → Player
- **Atomic Transactions:** Transfer တစ်ခုစီကို V7 Ledger မှတစ်ဆင့် Row-level locking ဖြင့် လုပ်ဆောင်သောကြောင့် ငွေပျောက်ခြင်း၊ Balance လွဲခြင်း လုံးဝမရှိနိုင်ပါ။
- **Logic:** `server/v7_agent_service.ts` ရှိ `transferCredit()` function ကို ကြည့်ပါ။

---

## 🛠 How to Use (Code Example)

### Admin Minting (Credit ထုတ်ခြင်း)
```ts
const agentService = new AgentService();
await agentService.mintCredit(adminUserId, 1000000, "MINT_REF_001");
```

### Transfer to Agent (Agent ဆီ လွှဲပေးခြင်း)
```ts
await agentService.transferCredit(adminUserId, agentUserId, 500000, "TRANS_REF_001");
```

### Sub-Agent Transfer (Agent အချင်းချင်း လွှဲခြင်း)
```ts
await agentService.transferCredit(agentUserId, subAgentUserId, 100000, "TRANS_REF_002");
```
