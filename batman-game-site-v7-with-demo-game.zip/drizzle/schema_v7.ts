import { decimal, int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, json } from "drizzle-orm/mysql-core";

/**
 * V7 CORE BANKING / FINTECH OS LEVEL SCHEMA
 * Based on Principal Architect Review
 */

// 1. SYSTEM STATE CONTROL
export const systemState = mysqlTable("system_state", {
  id: int("id").primaryKey(),
  status: mysqlEnum("status", ["RUNNING", "READ_ONLY", "FROZEN", "RECOVERY"]).default("RUNNING").notNull(),
  lastFreezeAt: timestamp("lastFreezeAt"),
  freezeReason: text("freezeReason"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// 2. CAPABILITY-BASED AUTHORIZATION
export const permissions = mysqlTable("permissions", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 64 }).notNull().unique(), // e.g., 'JOURNAL_MINT_EXECUTE'
  description: text("description"),
});

export const rolePermissions = mysqlTable("role_permissions", {
  role: mysqlEnum("role", ["admin", "agent", "user"]).notNull(),
  permissionId: int("permissionId").notNull(),
});

// 3. CORE LEDGER (DOUBLE-ENTRY)
export const accounts = mysqlTable("accounts", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("ownerId").notNull(), // Links to users.id
  ownerType: mysqlEnum("ownerType", ["PLAYER", "AGENT", "SYSTEM"]).notNull(),
  accountType: mysqlEnum("accountType", ["CASH", "BONUS", "COMMISSION", "LIABILITY", "EQUITY"]).notNull(),
  currency: varchar("currency", { length: 3 }).default("MMK").notNull(),
  balance: decimal("balance", { precision: 20, scale: 4 }).default("0.0000").notNull(),
  lockedBalance: decimal("lockedBalance", { precision: 20, scale: 4 }).default("0.0000").notNull(),
  status: mysqlEnum("status", ["ACTIVE", "FROZEN", "CLOSED"]).default("ACTIVE").notNull(),
  version: int("version").default(0).notNull(), // Optimistic Locking
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const journals = mysqlTable("journals", {
  id: int("id").autoincrement().primaryKey(),
  referenceId: varchar("referenceId", { length: 128 }).notNull().unique(), // Idempotency Key
  type: mysqlEnum("type", ["ORIGINAL", "REVERSAL", "ADJUSTMENT", "CORRECTION"]).notNull(),
  description: text("description"),
  metadata: json("metadata"),
  status: mysqlEnum("status", ["PENDING", "COMMITTED", "REJECTED"]).default("PENDING").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  committedAt: timestamp("committedAt"),
});

export const journalLines = mysqlTable("journal_lines", {
  id: int("id").autoincrement().primaryKey(),
  journalId: int("journalId").notNull(),
  accountId: int("accountId").notNull(),
  debit: decimal("debit", { precision: 20, scale: 4 }).default("0.0000").notNull(),
  credit: decimal("credit", { precision: 20, scale: 4 }).default("0.0000").notNull(),
  balanceAfter: decimal("balanceAfter", { precision: 20, scale: 4 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// 4. INVARIANT SNAPSHOTS (For Reconciliation)
export const accountSnapshots = mysqlTable("account_snapshots", {
  id: int("id").autoincrement().primaryKey(),
  accountId: int("accountId").notNull(),
  balance: decimal("balance", { precision: 20, scale: 4 }).notNull(),
  journalId: int("journalId").notNull(), // Last journal entry included in this snapshot
  snapshotDate: timestamp("snapshotDate").defaultNow().notNull(),
});

// 5. AGENT HIERARCHY & COMMISSIONS
export const agentHierarchy = mysqlTable("agent_hierarchy", {
  id: int("id").autoincrement().primaryKey(),
  agentId: int("agentId").notNull(),
  parentId: int("parentId"), // For multi-level
  level: int("level").notNull(), // 1 for Master, 2 for Senior, etc.
  path: text("path").notNull(), // Materialized path for fast tree queries
});

export const commissionRates = mysqlTable("commission_rates", {
  id: int("id").autoincrement().primaryKey(),
  agentId: int("agentId").notNull(),
  gameCategoryId: int("gameCategoryId"),
  rate: decimal("rate", { precision: 5, scale: 2 }).notNull(), // e.g., 5.00 for 5%
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// 6. FRAUD & REAL-TIME STREAMING
export const fraudRules = mysqlTable("fraud_rules", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 128 }).notNull(),
  conditionJson: json("conditionJson").notNull(),
  action: mysqlEnum("action", ["BLOCK", "ALERT", "FREEZE_ACCOUNT"]).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
});

export const fraudAlerts = mysqlTable("fraud_alerts", {
  id: int("id").autoincrement().primaryKey(),
  journalId: int("journalId"),
  ruleId: int("ruleId").notNull(),
  severity: mysqlEnum("severity", ["LOW", "MEDIUM", "HIGH", "CRITICAL"]).notNull(),
  details: text("details"),
  status: mysqlEnum("status", ["OPEN", "INVESTIGATING", "RESOLVED", "FALSE_POSITIVE"]).default("OPEN").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// 7. GAME PROVIDERS & SEAMLESS WALLET
export const gameProviders = mysqlTable("game_providers", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 32 }).notNull().unique(), // e.g., 'PRAGMATIC', 'JILI'
  name: varchar("name", { length: 128 }).notNull(),
  secretKey: text("secretKey"),
  operatorId: varchar("operatorId", { length: 64 }),
  callbackUrl: text("callbackUrl"),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const externalGames = mysqlTable("external_games", {
  id: int("id").autoincrement().primaryKey(),
  providerId: int("providerId").notNull(),
  gameCode: varchar("gameCode", { length: 64 }).notNull(),
  gameName: varchar("gameName", { length: 128 }).notNull(),
  gameType: varchar("gameType", { length: 32 }), // SLOT, FISH, CASINO, LIVE_CASINO
  imageUrl: text("imageUrl"),
  isLive: boolean("isLive").default(false).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
});

export const gameSessions = mysqlTable("game_sessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  providerId: int("providerId").notNull(),
  token: varchar("token", { length: 255 }).notNull().unique(),
  status: mysqlEnum("status", ["ACTIVE", "EXPIRED"]).default("ACTIVE").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// 8. LOCAL INTERNAL GAMES (ShanWorld Style)
export const internalGames = mysqlTable("internal_games", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 128 }).notNull(),
  code: varchar("code", { length: 32 }).notNull().unique(), // e.g., 'SHAN_KOE_MEE', 'BURGYI'
  gameType: mysqlEnum("gameType", ["CARD", "FISH", "SLOT", "DICE"]).notNull(),
  minBet: decimal("minBet", { precision: 12, scale: 2 }).default("100.00").notNull(),
  maxBet: decimal("maxBet", { precision: 12, scale: 2 }).default("100000.00").notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const internalGameHistory = mysqlTable("internal_game_history", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  gameId: int("gameId").notNull(),
  betAmount: decimal("betAmount", { precision: 12, scale: 2 }).notNull(),
  winAmount: decimal("winAmount", { precision: 12, scale: 2 }).default("0.00").notNull(),
  status: mysqlEnum("status", ["PENDING", "COMPLETED", "CANCELLED"]).default("PENDING").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});
