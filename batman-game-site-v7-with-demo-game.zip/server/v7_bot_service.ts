import { db } from "./db";
import { accounts, journalLines } from "../drizzle/schema_v7";
import { eq, sql, desc } from "drizzle-orm";

export class BotService {
  /**
   * Handle Telegram Commands
   * Integration with V7 Core for secure operations
   */
  async handleCommand(chatId: string, command: string, args: string[]) {
    switch (command) {
      case "/balance":
        return await this.getBalance(chatId);
      case "/leaderboard":
        return await this.getLeaderboard();
      // Add more commands here
      default:
        return "Unknown command.";
    }
  }

  private async getBalance(chatId: string) {
    // Logic to link chatId to userId/accountId
    const [account] = await db.select().from(accounts).where(eq(accounts.ownerId, Number(chatId))).limit(1);
    return account ? `Your balance is: ${account.balance} MMK` : "Account not found.";
  }

  /**
   * Real-time Leaderboard System
   * Based on win amounts in journal lines
   */
  async getLeaderboard() {
    const topWinners = await db.execute(sql`
      SELECT accountId, SUM(debit) as totalWin
      FROM ${journalLines}
      WHERE debit > 0
      GROUP BY accountId
      ORDER BY totalWin DESC
      LIMIT 10
    `);

    return (topWinners as any[]).map((w, index) => ({
      rank: index + 1,
      accountId: w.accountId,
      totalWin: w.totalWin
    }));
  }
}
