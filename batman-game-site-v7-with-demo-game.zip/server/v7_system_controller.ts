import { db } from "./db";
import { systemState, accounts, journalLines } from "../drizzle/schema_v7";
import { eq, sql } from "drizzle-orm";
import { LedgerService } from "./v7_ledger_service";

export class SystemController {
  private ledger = new LedgerService();

  /**
   * EMERGENCY FREEZE
   * Stops all financial transactions immediately across the entire platform
   */
  async emergencyFreeze(reason: string) {
    await db.update(systemState)
      .set({ 
        status: "FROZEN", 
        lastFreezeAt: new Date(),
        freezeReason: reason
      })
      .where(eq(systemState.id, 1));
    
    console.log(`!!! SYSTEM WIDE FREEZE ACTIVATED: ${reason} !!!`);
  }

  /**
   * RESUME SYSTEM
   */
  async resumeSystem() {
    await db.update(systemState)
      .set({ status: "RUNNING" })
      .where(eq(systemState.id, 1));
  }

  /**
   * GLOBAL INVARIANT RECONCILIATION
   * Runs through all accounts to ensure zero drift
   */
  async runGlobalReconciliation() {
    const allAccounts = await db.select().from(accounts);
    const results = [];

    for (const account of allAccounts) {
      const validation = await this.ledger.validateInvariants(account.id);
      if (!validation.isValid) {
        results.push(validation);
        // Automatically freeze system if a major drift is detected
        if (validation.drift > 100) {
          await this.emergencyFreeze(`Critical balance drift detected in account ${account.id}`);
        }
      }
    }

    return {
      totalChecked: allAccounts.length,
      driftsDetected: results.length,
      drifts: results
    };
  }
}
