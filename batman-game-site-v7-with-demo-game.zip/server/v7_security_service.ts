import { db } from "./db";
import { permissions, rolePermissions, fraudRules, fraudAlerts, accounts } from "../drizzle/schema_v7";
import { eq, and, sql } from "drizzle-orm";

export class SecurityService {
  /**
   * Capability-based Authorization
   * Instead of roles, check for specific granular permissions
   */
  async checkCapability(userId: number, capabilityCode: string): Promise<boolean> {
    const result = await db.execute(sql`
      SELECT p.id 
      FROM ${permissions} p
      JOIN ${rolePermissions} rp ON p.id = rp.permissionId
      JOIN users u ON u.role = rp.role
      WHERE u.id = ${userId} AND p.code = ${capabilityCode}
    `);
    
    return (result as any[]).length > 0;
  }

  /**
   * Real-time Fraud Streaming Processor
   * Should be called before/after every critical transaction
   */
  async processFraudDetection(params: {
    accountId: number;
    amount: number;
    type: string;
    metadata?: any;
  }) {
    const activeRules = await db.select().from(fraudRules).where(eq(fraudRules.isActive, true));

    for (const rule of activeRules) {
      const condition = rule.conditionJson as any;
      
      // Example Rule: Velocity Check (Too many transactions in short time)
      if (condition.type === "VELOCITY") {
        const [recentCount] = await db.execute(sql`
          SELECT COUNT(*) as count 
          FROM journal_lines 
          WHERE accountId = ${params.accountId} 
          AND createdAt > NOW() - INTERVAL ${condition.intervalMinutes} MINUTE
        `) as any[];

        if (recentCount.count > condition.maxCount) {
          await this.triggerFraudAction(rule, params);
        }
      }

      // Example Rule: Large Transaction Amount
      if (condition.type === "LARGE_AMOUNT" && params.amount > condition.threshold) {
        await this.triggerFraudAction(rule, params);
      }
    }
  }

  private async triggerFraudAction(rule: any, params: any) {
    // 1. Log Alert
    await db.insert(fraudAlerts).values({
      ruleId: rule.id,
      severity: "HIGH",
      details: `Fraud detected for account ${params.accountId}: ${rule.name}`,
      status: "OPEN"
    });

    // 2. Execute Action
    if (rule.action === "FREEZE_ACCOUNT") {
      await db.update(accounts)
        .set({ status: "FROZEN" })
        .where(eq(accounts.id, params.accountId));
    }
  }
}
