import { db } from "./db";
import { accounts, journals, journalLines } from "../drizzle/schema_v7";
import { eq, sql } from "drizzle-orm";
import { LedgerService } from "./v7_ledger_service";

/**
 * V7 SEAMLESS WALLET ENGINE
 * Handles callbacks from external game providers (Pragmatic Play, JILI, etc.)
 */
export class SeamlessWalletService {
  private ledger = new LedgerService();

  /**
   * DEBIT (Betting): When a player spins/plays
   */
  async handleDebit(params: {
    userId: number;
    amount: number;
    transactionId: string; // Provider's transaction ID
    providerCode: string;
    gameCode: string;
  }) {
    const [account] = await db.select().from(accounts).where(eq(accounts.ownerId, params.userId)).limit(1);
    if (!account) throw new Error("USER_ACCOUNT_NOT_FOUND");

    return await this.ledger.executeTransaction({
      referenceId: `${params.providerCode}_DEBIT_${params.transactionId}`,
      type: "ORIGINAL",
      description: `Bet on ${params.gameCode} (${params.providerCode})`,
      entries: [
        { 
          accountId: account.id, 
          amount: params.amount, 
          type: "CREDIT" // Deduct from user
        },
        { 
          accountId: 1, // System Liability/Equity (Temporary holder for active bets)
          amount: params.amount, 
          type: "DEBIT" 
        }
      ],
      metadata: { provider: params.providerCode, transactionId: params.transactionId }
    });
  }

  /**
   * CREDIT (Win): When a player wins
   */
  async handleCredit(params: {
    userId: number;
    amount: number;
    transactionId: string;
    providerCode: string;
    gameCode: string;
  }) {
    const [account] = await db.select().from(accounts).where(eq(accounts.ownerId, params.userId)).limit(1);
    if (!account) throw new Error("USER_ACCOUNT_NOT_FOUND");

    return await this.ledger.executeTransaction({
      referenceId: `${params.providerCode}_CREDIT_${params.transactionId}`,
      type: "ORIGINAL",
      description: `Win on ${params.gameCode} (${params.providerCode})`,
      entries: [
        { 
          accountId: 1, // System Equity (Source of win)
          amount: params.amount, 
          type: "CREDIT" 
        },
        { 
          accountId: account.id, 
          amount: params.amount, 
          type: "DEBIT" // Add to user
        }
      ],
      metadata: { provider: params.providerCode, transactionId: params.transactionId }
    });
  }

  /**
   * GET BALANCE: For Provider to check user balance
   */
  async getBalance(userId: number) {
    const [account] = await db.select().from(accounts).where(eq(accounts.ownerId, userId)).limit(1);
    return account ? parseFloat(account.balance) : 0;
  }
}
