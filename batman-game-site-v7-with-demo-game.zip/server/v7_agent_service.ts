import { db } from "./db";
import { agentHierarchy, commissionRates, accounts } from "../drizzle/schema_v7";
import { eq, sql, and } from "drizzle-orm";
import { LedgerService } from "./v7_ledger_service";
import { SecurityService } from "./v7_security_service";

export class AgentService {
  private ledger = new LedgerService();
  private security = new SecurityService();

  /**
   * ADMIN MINTING: Generate new credit into the system
   * ONLY ADMIN can call this
   */
  async mintCredit(adminUserId: number, amount: number, referenceId: string) {
    // 1. Check Capability (Security Layer)
    const canMint = await this.security.checkCapability(adminUserId, "JOURNAL_MINT_EXECUTE");
    if (!canMint) {
      throw new Error("UNAUTHORIZED: Only the Site Owner can generate credit.");
    }

    // 2. Execute Minting Transaction
    return await this.ledger.executeTransaction({
      referenceId,
      type: "ORIGINAL",
      description: "Admin Minting: New Credit Generated",
      isMinting: true,
      entries: [
        { 
          accountId: 1, // System Equity Account
          amount: amount, 
          type: "DEBIT" // Increasing system liability/equity to create credit
        }
      ]
    });
  }

  /**
   * TRANSFER CREDIT: Admin to Agent, or Agent to Agent (Tree structure)
   */
  async transferCredit(fromUserId: number, toUserId: number, amount: number, referenceId: string) {
    // 1. Verify Hierarchy (Optional: Ensure transfer is only going down the tree)
    // For now, simple transfer logic using V7 Ledger
    
    // Get Account IDs for users
    const [fromAccount] = await db.select().from(accounts).where(eq(accounts.ownerId, fromUserId)).limit(1);
    const [toAccount] = await db.select().from(accounts).where(eq(accounts.ownerId, toUserId)).limit(1);

    if (!fromAccount || !toAccount) throw new Error("ACCOUNTS_NOT_FOUND");

    return await this.ledger.executeTransaction({
      referenceId,
      type: "ORIGINAL",
      description: `Credit Transfer from ${fromUserId} to ${toUserId}`,
      entries: [
        { accountId: fromAccount.id, amount: amount, type: "CREDIT" }, // Deduct from sender
        { accountId: toAccount.id, amount: amount, type: "DEBIT" }    // Add to receiver
      ]
    });
  }

  /**
   * Multi-level Commission Distribution
   * When a player wins/loses, distribute commissions up the hierarchy
   */
  async distributeCommission(params: {
    playerId: number;
    gameId: number;
    gameCategoryId: number;
    amount: number; // The base amount to calculate commission from
    referenceId: string;
  }) {
    // 1. Get Agent for this player (assuming player has an assigned agent)
    // For this example, we'll fetch the hierarchy path
    const hierarchy = await db.select()
      .from(agentHierarchy)
      .where(eq(agentHierarchy.agentId, params.playerId)) // Simplified: player linked to agent
      .limit(1);

    if (hierarchy.length === 0) return;

    const agentIds = hierarchy[0].path.split('/').filter(id => id).map(Number);
    
    // 2. Distribute to each level in hierarchy
    for (const agentId of agentIds) {
      const rate = await db.select()
        .from(commissionRates)
        .where(and(
          eq(commissionRates.agentId, agentId),
          eq(commissionRates.gameCategoryId, params.gameCategoryId)
        ))
        .limit(1);

      if (rate.length === 0) continue;

      const commissionAmount = (params.amount * parseFloat(rate[0].rate)) / 100;

      if (commissionAmount <= 0) continue;

      // 3. Execute via V7 Ledger (Atomic & Safe)
      await this.ledger.executeTransaction({
        referenceId: `${params.referenceId}_COMM_${agentId}`,
        type: "ORIGINAL",
        description: `Commission for Game ${params.gameId}`,
        entries: [
          { 
            accountId: 1, // System Equity/Liability Account (Source)
            amount: commissionAmount, 
            type: "CREDIT" 
          },
          { 
            accountId: agentId, // Agent Commission Account (Destination)
            amount: commissionAmount, 
            type: "DEBIT" 
          }
        ]
      });
    }
  }

  /**
   * Create New Agent with Hierarchy Path
   */
  async createAgent(agentId: number, parentId?: number) {
    let path = `${agentId}/`;
    let level = 1;

    if (parentId) {
      const parent = await db.select()
        .from(agentHierarchy)
        .where(eq(agentHierarchy.agentId, parentId))
        .limit(1);
      
      if (parent.length > 0) {
        path = `${parent[0].path}${agentId}/`;
        level = parent[0].level + 1;
      }
    }

    await db.insert(agentHierarchy).values({
      agentId,
      parentId,
      level,
      path
    });
  }
}
