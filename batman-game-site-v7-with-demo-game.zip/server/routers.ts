import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import bcryptjs from "bcryptjs";
import { getPlayerByUsername, getPlayerById, getAgentByUsername, getAgentById, getGameCategories, getGamesByCategory, getDb } from "./db";
import { players, agents, gameCategories, games, gameHistory, transactions, announcements } from "../drizzle/schema";
import { eq } from "drizzle-orm";

// ============ PLAYER AUTHENTICATION ============

const playerAuthRouter = router({
  register: publicProcedure
    .input(
      z.object({
        username: z.string().min(3).max(64),
        password: z.string().min(6),
      })
    )
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

      const existing = await getPlayerByUsername(input.username);
      if (existing) {
        throw new TRPCError({ code: "CONFLICT", message: "Username already taken" });
      }

      const passwordHash = await bcryptjs.hash(input.password, 10);
      await db.insert(players).values({
        userId: 0,
        username: input.username,
        passwordHash,
        balance: "0.00",
        points: "0.00",
        status: "active",
      });

      return { success: true };
    }),

  login: publicProcedure
    .input(
      z.object({
        username: z.string(),
        password: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const player = await getPlayerByUsername(input.username);
      if (!player) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "Invalid credentials" });
      }

      const passwordMatch = await bcryptjs.compare(input.password, player.passwordHash);
      if (!passwordMatch) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "Invalid credentials" });
      }

      if (player.status !== "active") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Account is not active" });
      }

      // Set session cookie
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.cookie(COOKIE_NAME, JSON.stringify({ playerId: player.id, type: "player" }), cookieOptions);

      return {
        success: true,
        player: {
          id: player.id,
          username: player.username,
          balance: player.balance,
          points: player.points,
        },
      };
    }),

  logout: publicProcedure.mutation(({ ctx }) => {
    const cookieOptions = getSessionCookieOptions(ctx.req);
    ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
    return { success: true };
  }),
});

// ============ AGENT AUTHENTICATION ============

const agentAuthRouter = router({
  register: publicProcedure
    .input(
      z.object({
        username: z.string().min(3).max(64),
        password: z.string().min(6),
      })
    )
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });

      const existing = await getAgentByUsername(input.username);
      if (existing) {
        throw new TRPCError({ code: "CONFLICT", message: "Username already taken" });
      }

      const passwordHash = await bcryptjs.hash(input.password, 10);
      await db.insert(agents).values({
        userId: 0,
        username: input.username,
        passwordHash,
        agentType: "agent",
        status: "active",
      });

      return { success: true };
    }),

  login: publicProcedure
    .input(
      z.object({
        username: z.string(),
        password: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const agent = await getAgentByUsername(input.username);
      if (!agent) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "Invalid credentials" });
      }

      const passwordMatch = await bcryptjs.compare(input.password, agent.passwordHash);
      if (!passwordMatch) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "Invalid credentials" });
      }

      if (agent.status !== "active") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Account is not active" });
      }

      // Set session cookie
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.cookie(COOKIE_NAME, JSON.stringify({ agentId: agent.id, type: "agent" }), cookieOptions);

      return {
        success: true,
        agent: {
          id: agent.id,
          username: agent.username,
          agentType: agent.agentType,
        },
      };
    }),

  logout: publicProcedure.mutation(({ ctx }) => {
    const cookieOptions = getSessionCookieOptions(ctx.req);
    ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
    return { success: true };
  }),
});

// ============ GAME MANAGEMENT ============

const gameRouter = router({
  getCategories: publicProcedure.query(async () => {
    return await getGameCategories();
  }),

  getGamesByCategory: publicProcedure
    .input(z.object({ categoryId: z.number() }))
    .query(async ({ input }) => {
      return await getGamesByCategory(input.categoryId);
    }),

  getGameDetails: publicProcedure
    .input(z.object({ gameId: z.number() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return null;
      const result = await db.select().from(games).where(eq(games.id, input.gameId)).limit(1);
      return result.length > 0 ? result[0] : null;
    }),
});

// ============ PLAYER DASHBOARD ============

const playerDashboardRouter = router({
  getProfile: publicProcedure
    .input(z.object({ playerId: z.number() }))
    .query(async ({ input }) => {
      return await getPlayerById(input.playerId);
    }),

  getGameHistory: publicProcedure
    .input(z.object({ playerId: z.number(), limit: z.number().default(20) }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      return await db
        .select()
        .from(gameHistory)
        .where(eq(gameHistory.playerId, input.playerId))
        .limit(input.limit);
    }),

  getTransactionHistory: publicProcedure
    .input(z.object({ playerId: z.number(), limit: z.number().default(20) }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      return await db
        .select()
        .from(transactions)
        .where(eq(transactions.playerId, input.playerId))
        .limit(input.limit);
    }),

  updatePassword: publicProcedure
    .input(
      z.object({
        playerId: z.number(),
        currentPassword: z.string(),
        newPassword: z.string().min(6),
      })
    )
    .mutation(async ({ input }) => {
      const player = await getPlayerById(input.playerId);
      if (!player) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Player not found" });
      }

      const passwordMatch = await bcryptjs.compare(input.currentPassword, player.passwordHash);
      if (!passwordMatch) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "Current password is incorrect" });
      }

      const newPasswordHash = await bcryptjs.hash(input.newPassword, 10);
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      await db.update(players).set({ passwordHash: newPasswordHash }).where(eq(players.id, input.playerId));

      return { success: true };
    }),
});

// ============ AGENT TOOLS ============

const agentToolsRouter = router({
  topupCredit: publicProcedure
    .input(
      z.object({
        playerId: z.number(),
        amount: z.string(),
        agentId: z.number(),
      })
    )
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      const player = await getPlayerById(input.playerId);
      if (!player) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Player not found" });
      }

      // Create transaction
      await db.insert(transactions).values({
        type: "topup",
        playerId: input.playerId,
        agentId: input.agentId,
        amount: input.amount,
        status: "completed",
        description: `Credit top-up by agent ${input.agentId}`,
      });

      // Update player balance
      const currentBalance = parseFloat(player.balance.toString());
      const newBalance = (currentBalance + parseFloat(input.amount)).toFixed(2);
      await db.update(players).set({ balance: newBalance }).where(eq(players.id, input.playerId));

      return { success: true, newBalance };
    }),

  processWithdrawal: publicProcedure
    .input(
      z.object({
        playerId: z.number(),
        amount: z.string(),
        agentId: z.number(),
      })
    )
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      const player = await getPlayerById(input.playerId);
      if (!player) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Player not found" });
      }

      const currentBalance = parseFloat(player.balance.toString());
      const withdrawAmount = parseFloat(input.amount);
      if (currentBalance < withdrawAmount) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Insufficient balance" });
      }

      // Create transaction
      await db.insert(transactions).values({
        type: "withdrawal",
        playerId: input.playerId,
        agentId: input.agentId,
        amount: input.amount,
        status: "completed",
        description: `Withdrawal processed by agent ${input.agentId}`,
      });

      // Update player balance
      const newBalance = (currentBalance - withdrawAmount).toFixed(2);
      await db.update(players).set({ balance: newBalance }).where(eq(players.id, input.playerId));

      return { success: true, newBalance };
    }),

  getPlayerList: publicProcedure
    .input(z.object({ limit: z.number().default(50), offset: z.number().default(0) }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      return await db.select().from(players).limit(input.limit).offset(input.offset);
    }),

  getTransactionHistory: publicProcedure
    .input(z.object({ limit: z.number().default(50), offset: z.number().default(0) }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      return await db.select().from(transactions).limit(input.limit).offset(input.offset);
    }),
});

// ============ ANNOUNCEMENTS ============

const announcementRouter = router({
  getPublished: publicProcedure.query(async () => {
    const db = await getDb();
    if (!db) return [];
    return await db
      .select()
      .from(announcements)
      .where(eq(announcements.status, "published"));
  }),

  create: publicProcedure
    .input(
      z.object({
        titleEn: z.string(),
        titleMm: z.string(),
        contentEn: z.string(),
        contentMm: z.string(),
        type: z.enum(["notice", "alert", "announcement"]),
      })
    )
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });

      await db.insert(announcements).values({
        titleEn: input.titleEn,
        titleMm: input.titleMm,
        contentEn: input.contentEn,
        contentMm: input.contentMm,
        type: input.type,
        status: "draft",
      });

      return { success: true };
    }),
});

// ============ MAIN ROUTER ============

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  player: router({
    auth: playerAuthRouter,
    dashboard: playerDashboardRouter,
  }),
  agent: router({
    auth: agentAuthRouter,
    tools: agentToolsRouter,
  }),
  game: gameRouter,
  announcement: announcementRouter,
});

export type AppRouter = typeof appRouter;
