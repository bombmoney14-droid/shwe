import { db } from "./db";
import { accounts, journals, journalLines, systemState } from "../drizzle/schema_v7";
import { eq, sql, and } from "drizzle-orm";

export class LedgerService {
  /**
   * V7 Transaction Boundary Engine (TBE)
   * Implements strict serializable-like behavior using DB locks
   */
  async executeTransaction(params: {
    referenceId: string;
    type: "ORIGINAL" | "REVERSAL" | "ADJUSTMENT" | "CORRECTION";
    description: string;
    entries: { accountId: number; amount: number; type: "DEBIT" | "CREDIT" }[];
    metadata?: any;
    isMinting?: boolean; // New flag for money creation
  }) {
    return await db.transaction(async (tx) => {
      // 1. Check System State (Freeze Mechanism)
      const state = await tx.select().from(systemState).where(eq(systemState.id, 1)).limit(1);
      if (state[0]?.status === "FROZEN") {
        throw new Error("SYSTEM_FROZEN: All financial writes are currently disabled.");
      }

      // 2. Idempotency Check
      const existingJournal = await tx.select().from(journals).where(eq(journals.referenceId, params.referenceId)).limit(1);
      if (existingJournal.length > 0) {
        return existingJournal[0];
      }

      // 3. Double-Entry Validation
      const totalDebit = params.entries.filter(e => e.type === "DEBIT").reduce((sum, e) => sum + e.amount, 0);
      const totalCredit = params.entries.filter(e => e.type === "CREDIT").reduce((sum, e) => sum + e.amount, 0);
      
      // If minting, we allow creating money from 'System Equity' (Account 1)
      if (!params.isMinting && Math.abs(totalDebit - totalCredit) > 0.0001) {
        throw new Error("UNBALANCED_JOURNAL: Debits must equal Credits.");
      }

      // 4. Create Journal entry (Pending)
      const [journal] = await tx.insert(journals).values({
        referenceId: params.referenceId,
        type: params.type,
        description: params.description,
        metadata: params.metadata,
        status: "PENDING"
      });

      const journalId = journal.insertId;

      // 5. Process Entries with Row-Level Locking (FOR UPDATE)
      for (const entry of params.entries) {
        // SELECT ... FOR UPDATE (Transaction Boundary)
        const [account] = await tx.execute(sql`
          SELECT * FROM ${accounts} 
          WHERE id = ${entry.accountId} 
          FOR UPDATE
        `) as any[];

        if (!account) throw new Error(`ACCOUNT_NOT_FOUND: ${entry.accountId}`);
        if (account.status === "FROZEN") throw new Error(`ACCOUNT_FROZEN: ${entry.accountId}`);

        const currentBalance = parseFloat(account.balance);
        const newBalance = entry.type === "DEBIT" 
          ? currentBalance + entry.amount 
          : currentBalance - entry.amount;

        // Check for insufficient funds (if applicable)
        if (newBalance < 0 && account.accountType === "CASH") {
          throw new Error(`INSUFFICIENT_FUNDS: Account ${entry.accountId}`);
        }

        // Update Account Balance
        await tx.update(accounts)
          .set({ 
            balance: newBalance.toString(),
            version: account.version + 1 
          })
          .where(and(eq(accounts.id, entry.accountId), eq(accounts.version, account.version)));

        // Create Journal Line
        await tx.insert(journalLines).values({
          journalId: Number(journalId),
          accountId: entry.accountId,
          debit: entry.type === "DEBIT" ? entry.amount.toString() : "0.0000",
          credit: entry.type === "CREDIT" ? entry.amount.toString() : "0.0000",
          balanceAfter: newBalance.toString()
        });
      }

      // 6. Commit Journal
      await tx.update(journals)
        .set({ status: "COMMITTED", committedAt: new Date() })
        .where(eq(journals.id, Number(journalId)));

      return { journalId, status: "SUCCESS" };
    });
  }

  /**
   * V7 Invariant Validator Engine
   * Checks for balance drifts between journal totals and account snapshots
   */
  async validateInvariants(accountId: number) {
    const [account] = await db.select().from(accounts).where(eq(accounts.id, accountId)).limit(1);
    
    const [computed] = await db.select({
      total: sql<string>`SUM(debit) - SUM(credit)`
    })
    .from(journalLines)
    .where(eq(journalLines.accountId, accountId));

    const computedBalance = parseFloat(computed.total || "0");
    const actualBalance = parseFloat(account.balance);

    const drift = Math.abs(computedBalance - actualBalance);
    
    return {
      accountId,
      isValid: drift < 0.0001,
      drift,
      computedBalance,
      actualBalance
    };
  }
}
